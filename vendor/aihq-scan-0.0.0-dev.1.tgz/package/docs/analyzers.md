# External analyzers: SkillSpector and Cisco skill-scanner

Scan routes Text, Code and Config parts (`aih-scan-routing/1`) to SkillSpector, its
primary external analyzer. Cisco skill-scanner is an optional second opinion that runs
only when a request names it. `aih-trust-lint` is built in and always runs. Both external
analyzers are installed by you; Scan never downloads or installs them.

Valid UTF-8 files ending in `.kiro.hook` (case-insensitive, without NUL bytes) receive
Text analysis under their original paths, bytes and modes. Existing Config and Code
matches take precedence. Kiro `when`/`then` instructions are inspected as text; Scan
does not execute their actions or extract commands or dependencies from those fields.
Malformed JSON can still receive Text analysis, as other text files do; this does not
establish valid hook configuration. Binary files receive no analysis part. The suffix
does not add a source-discovery layout: use caller-prepared items for a hook item, or
find these files within an owning item or the source's remaining files.

| Tool | Pinned release | Runs | Counts for coverage |
|---|---|---|---|
| SkillSpector | 2.13.7 (NVIDIA/SkillSpector tag `v2.13.7`, commit `c323ad4c43e3c8f2de051572cc25b2711d11e648`) | by default | yes |
| Cisco skill-scanner | 2.3.2 (PyPI `cisco-ai-skill-scanner==2.3.2`) | only with `--tools …,cisco` | never |

## Installing

Both are Python command-line tools. The locked runtimes in `tools/analyzers/` pin every
dependency (PyPI packages by hash, SkillSpector by commit); install either one with [uv](https://docs.astral.sh/uv/):

```sh
UV_PROJECT_ENVIRONMENT=$HOME/.aih-scan/skillspector \
  uv sync --project tools/analyzers/skillspector --locked --no-install-project
UV_PROJECT_ENVIRONMENT=$HOME/.aih-scan/cisco \
  uv sync --project tools/analyzers/cisco-skill-scanner --locked --no-install-project
```

Without the repository, `uv tool install "skillspector @ git+https://github.com/NVIDIA/SkillSpector@c323ad4c43e3c8f2de051572cc25b2711d11e648"`
and `uv tool install cisco-ai-skill-scanner==2.3.2` put the commands in `~/.local/bin`
(unlocked transitive dependencies).

## How Scan finds them

For each tool Scan looks, in order, at:

1. `AIH_SCAN_SKILLSPECTOR` / `AIH_SCAN_SKILL_SCANNER`: an absolute path to the executable,
   or `none` to disable the tool (it is then reported `not-run`, reason `unavailable`);
2. the directories on your `PATH`;
3. the usual install folders (`~/.local/bin`, `/usr/local/bin`, `/usr/bin`, Homebrew).

On Windows only `skillspector.exe` and `skill-scanner.exe` are accepted (the console
entry points a Python environment creates in `Scripts\`), never a `.cmd`, `.bat` or
`.ps1` shim. Before scanning, Scan asks the found executable for `--version` and refuses
any other release (`not-run`, reason `unavailable`, with the version found in the
result's notes). Nothing is run from the scanned content.

## How a run works

Each item is copied into Scan's own read-only working copy; the analyzers read only that
copy. Each analyzer runs natively (no Docker, Windows included) as one shell-free child
process whose whole process tree is contained (a POSIX process group, or a Windows Job
Object with kill-on-close), limited to ten minutes per tool and item, and ended at once
when you cancel. A timeout is `not-run` with reason `timeout` and makes that item
`partial`; cancelling returns `cancelled` and keeps the finished results. Reports are
written to a private scratch folder outside the working copy and the output folder, read
with a size bound, and removed.

The copy preserves the source bytes. POSIX permissions also prevent adding files to the
working directory. Windows read-only attributes protect existing copied files but do not
prevent creating new entries in that directory; they are not an analyzer sandbox.

### SkillSpector

```
skillspector scan <working-copy> --format json [--output <scratch>/report.json] [--no-llm]
```

On Windows Scan omits `--output`: the pinned SkillSpector does not support safe file
output there. Scan reads its JSON from bounded stdout instead, with the same 64 MiB
report limit and strict UTF-8/JSON validation. Other platforms retain the private report
file. Logs stay on stderr; truncated, malformed or mixed progress/JSON stdout is refused.

- **Static (default).** `--no-llm`, and a scrubbed environment: only what Python needs
  to start, a private HOME/TEMP, no proxy, credential, provider or Python loader
  variables. Scan also sets `SKILLSPECTOR_OSV_TIMEOUT=0`, which stops SkillSpector's own
  live OSV.dev lookup before any request: known vulnerabilities come only from the
  separate `checkAdvisories` call, so SkillSpector's SC4 findings are not part of a scan,
  and the disabled lookup is not counted as a coverage gap. The analysis makes no network
  call. Scan never passes `--transitive*`, `--mcp-registry`, `--use-shipped-baseline`
  (author-supplied suppressions) or a URL input.
- **AI (`--mode ai`).** The static checks plus SkillSpector's AI pass, using the AI you
  already set up through SkillSpector's own settings, passed through unchanged:
  `SKILLSPECTOR_PROVIDER`, `SKILLSPECTOR_MODEL` and the provider's variables. Scan adds no
  model, budget or credential store and records only how the AI ran (`cli`, `local` or
  `provider`), the provider and the model, never a credential. The command says before
  scanning that the scanned content is sent to that AI.

  For a signed-in agent CLI that reports its version, the summary's `ai` record also names the
  client and that version (`client: { "name": "claude", "version": "2.1.330" }`), so a reader can tell an
  agent-CLI pass from an HTTP provider. Without `SKILLSPECTOR_MODEL` the model is recorded as
  `provider default`: the CLI's own choice, which Scan cannot see.

  **Claude CLI effort.** SkillSpector has no effort setting for `claude_cli`. Set Scan's own
  `AIH_SCAN_AI_EFFORT` to `low`, `medium`, `high`, `xhigh` or `max` to run the pass at that
  effort. Scan records `effort` in the summary. For Claude, Scan applies the setting on
  Linux and macOS: another provider, an unknown level or a Windows host is reported as "AI not
  available here" with the reason, never silently ignored. In static mode the setting has no
  effect, and the result notes say so. Without it, the CLI uses its own default effort and no
  effort is recorded.

  **Which Claude CLI runs.** For `claude_cli` on Linux and macOS, Scan resolves the real
  `claude` binary on `PATH`, records the version it reports as `client`, and puts a private
  launcher first on SkillSpector's `PATH`. The launcher starts exactly that binary with its
  auto-updater disabled (`DISABLE_AUTOUPDATER=1`) and, with an effort, adds
  `--effort <level>` to each `-p` call; nothing else in the call changes. If the CLI reports no
  version, an effort-controlled pass does not start (SkillSpector `not-run`, `failed`). When
  SkillSpector reports that its analyzers used a model other than `SKILLSPECTOR_MODEL`, the
  summary records the reported model, not the requested one.

  **Kimi Code CLI.** On POSIX, set `SKILLSPECTOR_PROVIDER=kimi_cli`,
  `SKILLSPECTOR_MODEL=kimi-for-coding` and `AIH_SCAN_AI_EFFORT` to `low`, `high` or
  `max`. For Kimi K3, set `SKILLSPECTOR_MODEL=k3` and `AIH_SCAN_AI_EFFORT=max`.
  Use Kimi Code CLI 2.7.2 on PATH and sign in to the managed Kimi Code provider.
  The model ID identifies K2.8 Preview for eligible accounts. The default login region is
  `global`. For a mainland China login set `AIH_SCAN_KIMI_REGION=mainland-cn`. Scan uses
  `KIMI_CODE_HOME` when set, otherwise `~/.kimi-code`.

  Scan uses Kimi's ACP stdio protocol with a fresh private workspace and
  settings that remove all model-callable tools. The Kimi client handles the existing
  OAuth login. Scan verifies the selected model and effort in the Kimi session before
  sending a prompt. Completed evidence records `kimi_cli`, the effective model, the
  selected effort and `client: { "name": "kimi", "version": "2.7.2" }`.
  The Kimi route reports incomplete analysis when authentication, provider response,
  model or effort selection fails.

  Prepared campaigns can explicitly select `adaptive-ssd/1` with Kimi K3 at max effort.
  The prepared broker and the pinned SkillSpector runtime must both support this profile.
  Scan records it as `ai.profile` after verifying that the semantic security discovery
  detector used the selected path. The profile changes the detector prompt context and
  is a distinct evidence configuration. Ordinary Kimi K3 and K2.8 assessments retain
  their existing one-request detector behavior.

  **Codex CLI.** Scan reports `codex_cli` unavailable because Codex CLI 0.171.0
  lacks a verified public configuration that removes every model-callable tool.

  AI counts as set up when `SKILLSPECTOR_PROVIDER` names a supported provider and its
  required settings are present:

  | Provider | Via | Needs |
  |---|---|---|
  | `claude_cli`, `gemini_cli`, `opencode_cli` | cli | the `claude`, `gemini` or `opencode` CLI on PATH, signed in |
  | `kimi_cli` | cli | Kimi Code CLI 2.7.2 on PATH, managed sign-in, exact model ID and explicit effort |
  | `ollama` | local | a local Ollama service |
  | `openai_compatible` | local for a loopback `SKILLSPECTOR_COMPAT_BASE_URL`, else provider | `SKILLSPECTOR_COMPAT_BASE_URL` and `SKILLSPECTOR_COMPAT_API_KEY` (both required, including for a local service) |
  | `openai`, `anthropic`, `anthropic_proxy`, `azure_openai`, `bedrock`, `nv_build`, `nv_inference` | provider | the provider's key or profile variables |
  | `gemini`, `minimax` | — | available upstream and reported as "AI not available here" by Scan |

  An explicit model selection is forwarded unchanged. When no model is selected for
  `nv_build`, SkillSpector 2.13.7 defaults to `z-ai/glm-5.3-flash`.

  Scan never picks a provider for you: with `SKILLSPECTOR_PROVIDER` unset (or naming an
  unavailable provider such as `codex_cli`), the result says "AI not available here"
  with the reason, SkillSpector runs static only, nothing is sent to an AI, and coverage is
  measured exactly as for a static scan. When AI is set up but its pass does not complete,
  the item is `partial` (reason `failed`). A usable partial report keeps its static and
  usable recovered AI findings. If the whole SkillSpector process or report fails, Scan
  reports the tool `not-run` / `failed` and does not retain that failed report's findings;
  findings from other completed tools remain. Available fatal report reason codes stay in
  the diagnostic notes.

  In AI mode Scan forwards the caller's environment except Python loader variables and the
  OSV timeout. SkillSpector's own resource and limit controls (`SKILLSPECTOR_*` caps such as
  archive member, ledger event, parser source and TP4 byte limits) therefore come from the
  caller's environment. They are not recorded and are not part of the result identity, so
  two AI scans with different caps can carry the same identity. A lowered cap still surfaces
  as an inspection gap and leaves the item `partial`. Static mode and prepared publisher
  profiles forward only an allowlist, so ambient caps never apply there.
  SkillSpector 2.13.7 runs semantic security batches asynchronously through its shared
  concurrency control (`SKILLSPECTOR_MAX_LLM_CONCURRENCY`), preserving batch result
  order. A lossless formatting repair can complete; a field-recovered assessment remains
  `partial` even when upstream accepts its formatting-recovery policy. Refusals, unfinished
  or unusable AI responses remain incomplete inspection and distinct from security findings.
  Scan's ten-minute per-tool deadline remains the outer bound, even though this
  upstream release defaults to an eighteen-minute workflow deadline. Large inputs can
  still time out; parallel execution does not guarantee completion within Scan's limit.
- **Results.** SkillSpector's rule id, severity and confidence are kept; each ordinary finding
  is placed at its primary location's file and line, which must be a file of the item routed
  to SkillSpector. For a supported archive member, the finding names the exact outer archive
  with `part: none` and that file's existing SHA-256; the member path and line stay in the
  finding text. Codes come from `aih-codes/1` (`codes.tools.skillspector`), SkillSpector's own
  risk score is ignored and `aih-risk/1` scores the findings. Exit 1 (SkillSpector's own risk
  threshold) is a finished run; exit 2, a missing report or a failed analysis is `not-run`,
  reason `failed`; another executable or report version is refused as described above. When
  SkillSpector could not fully inspect a routed file or a supported archive member, the item
  is `partial` (reason `failed`) with an unsigned note. Scan also reconciles the report's
  recognized `status` / `is_complete` state, limitations, recovery warnings and
  partially/entirely-uninspected file aggregates; omission-only or unexplained partial states
  cannot become complete, and missing or inconsistent completeness metadata is refused. Gaps
  on files no tool is routed (binaries, dependency manifests) and the disabled upstream OSV
  lookup are not reported as gaps. Their derived limitations and aggregate omissions are
  excluded only when positively matched to those components; unrelated or excess omissions
  remain partial. Only a positively identified reference-only `complete_with_caveats` report
  stays `complete` and carries its caveat note instead. Fields that SkillSpector 2.13.5 added
  outside the status also leave the item `partial`: documentation `notices`, caller exclusions
  (`exclude_patterns` / `excluded_file_count`) and any `dependency_inspection` other than the
  untouched default (`enabled: false`, `status: "not_requested"`, no inspected artifacts). A
  report without that summary is also `partial`, because 2.13.7 always writes it. Scan
  requests none of these, and malformed values are refused.

### DeepSeek Flash on Windows

Use SkillSpector's existing `openai_compatible` HTTP provider with the exact model
`deepseek-flash` and endpoint `https://api.deepseek.com`, as specified by
[DeepSeek's API guide](https://api-docs.deepseek.com/quick_start/agent_integrations/).
This uses your DeepSeek API key and API billing, rather than a ChatGPT subscription.
Static analysis stays on your PC; SkillSpector sends the content for its AI pass to DeepSeek.
No agent CLI or model-driven host command executor is involved.

The pinned SkillSpector uses LangChain's schema-bound response parser. DeepSeek does not
support its default `json_schema` response format. Select `function_calling` explicitly:
the functions describe the findings response schema; SkillSpector parses the returned
arguments as data and does not execute them. Also select reasoning effort `none`, which
disables thinking so DeepSeek accepts the forced schema function. This is the
non-thinking route; it changes DeepSeek's default thinking behavior. See
[DeepSeek's request contract](https://api-docs.deepseek.com/api/create-chat-completion/).
Keep other reasoning modes on a separately verified integration; `json_mode` alone does
not add the schema instructions that this pinned analyzer's prompts require.

After installing the locked SkillSpector runtime above and making your key available in
the current terminal as `DEEPSEEK_API_KEY`, run this in PowerShell. Replace the executable,
input and output paths with your own. These settings affect this terminal and its child
processes only; they do not change global defaults or write a credential file.

```powershell
if ([string]::IsNullOrWhiteSpace($env:DEEPSEEK_API_KEY)) { throw 'DEEPSEEK_API_KEY is not set' }
$env:AIH_SCAN_SKILLSPECTOR = 'C:\tools\skillspector\Scripts\skillspector.exe'
$env:SKILLSPECTOR_PROVIDER = 'openai_compatible'
$env:SKILLSPECTOR_COMPAT_BASE_URL = 'https://api.deepseek.com'
$env:SKILLSPECTOR_COMPAT_API_KEY = $env:DEEPSEEK_API_KEY
$env:SKILLSPECTOR_MODEL = 'deepseek-flash'
$env:SKILLSPECTOR_REASONING_EFFORT = 'none'
$env:SKILLSPECTOR_STRUCTURED_OUTPUT_METHOD = 'function_calling'
aih-scan scan 'C:\skills\example' --mode ai --out 'C:\scan-output\example' --json
```

Remove any existing `SKILLSPECTOR_MODEL_<SLOT>` overrides if you intend every analyzer
to use `deepseek-flash`; SkillSpector otherwise honors those more-specific caller settings.
Scan does not select another model or a paid fallback. The pinned SkillSpector's bundled
model metadata predates this alias, so it warns and uses its existing 128,000-token
fallback for context budgeting; it still requests the exact `deepseek-flash` model.

Having the endpoint and key set establishes configuration readiness; authentication,
balance, quota and parsed findings are established only by the run. Failed or malformed
AI analysis cannot establish complete coverage. A usable partial report retains its
findings, but a whole SkillSpector failure (including an exit 2 after a quota error)
is `not-run` / `failed` and its raw report's static findings are not retained. Findings
from other completed tools remain. Inspect coverage and notes, and rerun after resolving
the provider failure; exit zero or an available configuration does not prove complete
AI analysis.

### Cisco skill-scanner

```
cd <working-copy> && skill-scanner scan . --use-behavioral --format json --output-json <scratch>/cisco.json
```

Always static, also in AI mode, with the scrubbed environment; Scan never passes
`--use-llm`, `--use-virustotal`, `--vt-upload-files`, `--use-aidefense`, `--use-osv`,
`--enable-meta`, `--adjudicate` or `--system-one-endpoint`, and never uses `scan-repo`.
Cisco reads skills: an item without a root `SKILL.md` is `not-applicable` (its lenient
fallback reports findings against a `SKILL.md` that does not exist). Its findings use
SARIF, `aih-codes/1` (by Cisco category, `codes.categories.cisco`) and `aih-risk/1` like any
tool's, with cross-tool deduplication: the same code, file and line from two tools counts
once. Cisco has no confidence field. Its unavailable, failed, timed-out or not-applicable
outcomes are listed, but Cisco never makes required coverage partial.

#### Behavioral analysis does not execute supplied code

`--use-behavioral` is routed because the pinned 2.3.2 documentation and implementation
establish that it parses and does not run code:

- Upstream documentation at the 2.3.2 commit
  (`cisco-ai-defense/skill-scanner@f7824651ffeb9b89f7682ddd97d6fba8fe9c10b1`,
  `docs/architecture/analyzers/behavioral-analyzer.md`): "uses static code analysis with
  AST parsing and dataflow tracking"; "**No Code Execution**: All analysis is static (AST
  parsing only)"; "Execution model: Static AST/dataflow analysis only (no runtime code
  execution)"; its comparison table lists the behavioral analyzer's code execution as "No".
- Installed 2.3.2 implementation: `skill_scanner/core/analyzers/behavioral_analyzer.py`
  ("Detects threats through code analysis without execution"; Python by AST dataflow,
  shell by lightweight taint tracking). Its parsers use `ast.parse` only
  (`core/static_analysis/parser/python_parser.py`, `interprocedural/call_graph_analyzer.py`,
  `context_extractor.py` and the Python shell-semantics modules). Every `subprocess`,
  `os.system`, `exec`, `eval`, `runpy`, `__import__`, `Popen`, `ctypes` or `pickle.load`
  occurrence in `core/static_analysis` and the behavioral analyzer is a sink name or pattern
  used for detection, not a call. `core/analyzer_factory.py` builds the analyzer for
  `--use-behavioral` with LLM alignment verification left off, so it adds no network use.
- Scan's own tests run the real 2.3.2 scanner with `--use-behavioral` on fixtures whose
  scripts, hooks, package scripts, Python module and compiled module would each leave a
  sentinel file if anything executed or imported them, with the network removed; no
  sentinel appears.

**Supplied `.pyc` files.** Cisco's always-on bytecode analyzer (not the behavioral one)
checks a supplied `.pyc` against its sibling `.py`: after validating the header it reads
the code object with `marshal.load` and compiles the `.py` source to compare
(`core/analyzers/bytecode_analyzer.py`). Neither step executes code, but Python documents
`marshal` as not secure against maliciously constructed data, which can at worst crash the
Cisco process. Scan keeps `.pyc` files in what Cisco reads, so that Cisco's
bytecode-tampering check still works: a crash is contained to the Cisco child process and
reported as a `failed` Cisco outcome, which never affects required coverage. Callers who
do not want this can leave Cisco unselected (the default). Scan routes `.pyc` files to no
tool; they are listed in `notAnalysed` with `secretsChecked: false`.

Treat this as a real exposure, not only a crash risk: never unmarshal untrusted data in your
own tooling, and when you select Cisco for content you do not trust, run Scan inside an
operating-system sandbox (a container, VM or unprivileged user namespace with no network and
no access to your credentials) so that a flaw in Python's `marshal` or in any analyzer parser
cannot reach the host.

## Isolation

Scan keeps analyzers static and off the network by their own flags and by the environment it
passes (no provider, proxy or credential variables, a private HOME and TEMP); it does not
place them in an operating-system sandbox. Their parsers still read untrusted content with
your user's file-system rights. For untrusted content, run Scan in an isolated environment
(a container or VM without credentials, or on Linux `unshare -rn aih-scan scan <folder>`, which
removes the network for Scan and every analyzer it starts, so only local folders and
tarballs can be scanned and the AI mode has no provider).

## Platform notes

Native Windows runs use `.exe` entry points and a Windows Job Object. SkillSpector's
Windows JSON stdout transport is exercised through the installed package with its real
locked runtime and a synthetic local HTTP service, including malformed responses and
quota errors. This fixture verifies transport and parsing; it does not establish live
provider availability or assessment quality. The real static analyzers have also been
exercised on Linux x64.

## Optional TP4 maintenance build

Upstream 2.13.7 retains a fixed 64-finding TP4 limit and reads its 128-source default from
`SKILLSPECTOR_TP4_MAX_FILES`. Scan still refuses either TP4 capacity variable on the standard
release, so its source and finding capacities stay at upstream defaults. Scan also supports a
separately identified reproducible 2.13.7-based maintenance artifact, documented with its
patch review in `tools/analyzers/skillspector/maintenance/README.md`. It preserves upstream
defaults and makes file/finding capacities explicit without editing an installed analyzer.
Prepared profiles bind the exact maintenance version/wheel and requested capacities;
executable, report and resolved-capacity identities must agree before observations are
accepted. New scans and prepared profiles do not admit the previous 2.13.3 or 2.13.4
maintenance wheels. Completed historical summaries and findings remain readable under their original
producer identities through the existing public readers. Building/installing the
maintenance artifact and increasing capacities are explicit operator choices; more
source/batch work can cost more and does not guarantee complete inspection.
